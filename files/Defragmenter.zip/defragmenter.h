#ifndef defragmenterH
  #define defragmenterH

#include "mynew.h"
#include "DefragRunner.h"

using namespace std;

class Defragmenter
{
public:
  Defragmenter(DiskDrive *diskDrive);
  static void defrag(DiskDrive *diskDrive, unsigned* startPos, pair<unsigned short, unsigned short> *parallelDir, bool* correct);
  static void calcStartPos(DiskDrive* diskDrive, unsigned* startPos);
  static void createDir(DiskDrive *diskDrive, pair<unsigned short, unsigned short> *parallelDir, bool* correct, unsigned* startPos);
  static int desiredPos(pair<unsigned short, unsigned short> parallelBlock, unsigned* startPos);
  static void reorder(DiskDrive *diskDrive, pair<unsigned short, unsigned short> *parallelDir, unsigned pos, unsigned* startPos, bool* correct);
  static void print(pair<unsigned short, unsigned short> *parallelDir, int pos, int tempPos, bool* FAT, pair<unsigned short, unsigned short> tempElement, bool* correct);

}; // class Defragmenter

#endif